<?php
    error_reporting(E_ALL);
    ini_set('display_errors', '1');

        $DB = new SQLite3('sensor.db');
        $sensor_group = $_GET["sensor_group"];
        $sensor_name = $_GET["sensor_name"];
        $sensor_data = $_GET["sensor_data"];
        $DB->exec("INSERT INTO sdata ('sensor_group', 'sensor_name', 'sensor_data') VALUES ('$sensor_group', '$sensor_name','$sensor_data')");

#ln -sf /usr/share/zoneinfo/Asia/Seoul /etc/localtime
#chown www-data /myproject
#CREATE TABLE content (id integer primary key, before TEXT NOT NULL, now TEXT NOT NULL, time text DEFAULT (datetime('now','localtime')) );
#INSERT INTO content ('before', 'now') VALUES ('a','b');
 ?>
<script>
   alert("저장 되었습니다!");
   history.back();
</script>

