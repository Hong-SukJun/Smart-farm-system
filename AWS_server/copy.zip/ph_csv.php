<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

$DB = new SQLite3('sensor.db');

$result = $DB->query("SELECT * FROM sdata WHERE sensor_name = 'pH'");

$sensorData = array();

while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $sensorData[] = array(
        'time' => date('Y-m-d H:i', strtotime($row['data_time'])),
        'sensor_group' => $row['sensor_group'],
        'sensor_name' => $row['sensor_name'],
        'sensor_data' => $row['sensor_data']
    );
}

// CSV 텍스트 생성
$csvText = "Time,Sensor Group,Sensor Name,Sensor Data\n";

foreach ($sensorData as $data) {
    $row = array(
        $data['time'],
        $data['sensor_group'],
        $data['sensor_name'],
        $data['sensor_data']
    );
    $csvText .= implode(',', $row) . "\n";
}

// 다운로드 헤더 설정
header('Content-Type: application/csv');
header('Content-Disposition: attachment; filename="sensor_data.csv"');

// CSV 텍스트 출력
echo $csvText;
?>