<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

$DB = new SQLite3('sensor.db');

$result = $DB->query("SELECT * FROM sdata WHERE sensor_name = 'Temperature(°C)';");

$sensorData = array();

while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $sensorData[] = array(
        'time' => date('H:i', strtotime($row['data_time'])),
        'sensor_name' => $row['sensor_name'],
        'sensor_group' => $row['sensor_group'],
        'sensor_data' => $row['sensor_data']
    );
}

header('Content-Type: application/json');
echo json_encode($sensorData);
?>
