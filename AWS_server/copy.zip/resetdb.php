<?php
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    function rmdirAll($dir) {
        $dirs = dir($dir);
        while(false !== ($entry = $dirs->read())) {
           if(($entry != '.') && ($entry != '..')) {
              if(is_dir($dir.'/'.$entry)) {
                 rmdirAll($dir.'/'.$entry);
              } else {
                 @unlink($dir.'/'.$entry);
              }
            }
         }
         $dirs->close();
         @rmdir($dir);
     }
        $DB = new SQLite3('./sensor.db');
        $DB->exec("DROP TABLE IF EXISTS sdata;");
        $DB->exec("CREATE TABLE sdata (id integer primary key AUTOINCREMENT, sensor_group TEXT NOT NULL, sensor_name TEXT NOT NULL, sensor_data TEXT NOT NULL, data_time TEXT DEFAULT(datetime('now','localtime')) );");
        echo "<script>alert(\"시스템이 초기화 되었습니다\"); location.href = document.referrer;</script>";
?>